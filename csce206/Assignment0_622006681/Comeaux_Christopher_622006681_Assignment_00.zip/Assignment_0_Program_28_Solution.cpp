#include <iostream>
using namespace std;

int main()
{

	const double PI = 3.14159;
	const double DIAMETER = 10.0;
	double circumference;
	
	circumference = PI * DIAMETER;
	
	cout<< "The circumference is: " <<circumference<<endl;
	return 0;
}