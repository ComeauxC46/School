// This program can't find its variable.

	#include <iostream>
	using namespace std;
	
	int main()
{
	  int value = 100;
	  cout << value;
	   return 0;
}
