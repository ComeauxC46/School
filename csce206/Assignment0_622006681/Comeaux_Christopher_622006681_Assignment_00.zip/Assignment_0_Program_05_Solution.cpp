#include <iostream>
using namespace std;

int main()
{
	cout << "The following items were top sellers" << endl;
	   cout << "during the month of June:" << endl;
	   cout << "Computer games" << endl;
	   cout << "Coffee" << endl;
	   cout << "Aspirin" << endl;
	   return 0;
}