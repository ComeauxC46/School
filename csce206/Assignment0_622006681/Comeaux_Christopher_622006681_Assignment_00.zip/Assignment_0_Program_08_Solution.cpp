// This program has a variable.
	#include <iostream>
	using namespace std;
 
int main()
{
	   int number;

	   number = 5;
	   cout << "The value in number is " << "number" << endl;      
	   return 0;
}
