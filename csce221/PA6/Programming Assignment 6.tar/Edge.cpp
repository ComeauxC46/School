#include "Edge.hpp"

Edge::Edge(int start, int end, int weight,bool visited)
		  : start(start), end(end), weight(weight), visited(visited){}