#include "Misc_Windows.h"


int main()
 {
	Splash_Window win00(Point(100,100),600,600,"Flip Nation");
    return gui_main();
}
